
package pizza.order.gui;

import javax.swing.JFrame;


public class PizzzaOrderFrameRunner {

    
    public static void main(String[] args) {
        
        JFrame frame = new PizzaOrderFrame();
    }
    
}
