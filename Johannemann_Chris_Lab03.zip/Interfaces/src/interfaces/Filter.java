
package interfaces;


public interface Filter {
    boolean accept(Object x);
    
}
