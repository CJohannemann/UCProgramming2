
package fortuneteller;

import java.io.IOException;
import javax.swing.JFrame;


public class FortuneTellerViewer {

    public static void main(String[] args) {
        
        JFrame frame = new FortuneTellerFrame();
        frame.setVisible(true);
    }
    
}
