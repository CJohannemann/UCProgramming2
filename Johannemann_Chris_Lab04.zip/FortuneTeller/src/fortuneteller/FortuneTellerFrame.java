package fortuneteller;

import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;

public class FortuneTellerFrame extends JFrame {

    private static final int FRAME_WIDTH = 355;
    private static final int FRAME_HEIGHT = 525;
    private static final int ROWS = 20;
    private static final int COLUMNS = 30;
    private JLabel label, labelImg;
    ArrayList<String> quotes = new ArrayList<>();

    JPanel contentPnl, controlPnl;
    JTextArea jta;
    JButton fortuneBtn, exitBtn;
    ImageIcon img;
    int curQuote = 0;

    FortuneTellerFrame() {

        
        quotes.add("The early bird gets the worm, but the second mouse gets the cheese.");
        quotes.add("Be on the alert to recognize your prime at whatever time of your life it may occur.");
        quotes.add("Your road to glory will be rocky, but fulfilling.");        
        quotes.add("Courage is not simply one of the virtues, but the form of every virtue at the testing point.");
        quotes.add("Patience is your alley at the moment. Don’t worry!");
        quotes.add("Nothing is impossible to a willing heart.");
        quotes.add("Don’t worry about money. The best things in life are free.");
        quotes.add("Don’t pursue happiness – create it.");
        quotes.add("Courage is not the absence of fear; it is the conquest of it.");
        quotes.add("Nothing is so much to be feared as fear.");
        quotes.add("All things are difficult before they are easy.");
        quotes.add("You don’t need strength to let go of something. What you really need is understanding.");

        jta = new JTextArea(ROWS, COLUMNS);
        jta.setEditable(false);

        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setTitle("Fortune Teller GUI");
        setLocationRelativeTo(null);
        setResizable(false);
        createButton();
        createTextField();
        exitButton();
        createPanel();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void createTextField() {
        label = new JLabel("Fortune Teller:");
        label.setFont(new Font("Courier New", Font.BOLD, 36));
        label.setForeground(Color.BLUE);
        img = new ImageIcon("fortunePicture.png");
        labelImg = new JLabel(img);
    }

    private void createButton() {
        fortuneBtn = new JButton("Read My Fortune!");
        fortuneBtn.setFont(new Font("Arial", Font.TRUETYPE_FONT, 14));
        fortuneBtn.setForeground(Color.GREEN);
        fortuneBtn.addActionListener((e) -> {
            StringBuilder txt = new StringBuilder();
            Random random = new Random();
            int randomNum = random.ints(1,0, 11).findFirst().getAsInt();
            int old = random.ints(1,0,11).findAny().getAsInt();
            if(randomNum <= old){
                randomNum++;
                System.out.println(randomNum +" less than "+ old);
                jta.append(quotes.get(randomNum)+"\n");
            }
            else if(randomNum >= old){
                randomNum--;
                System.out.println(randomNum +" greater than "+ old);
                jta.append(quotes.get(randomNum)+"\n");
            }
        });
    }

    private void exitButton() {
        exitBtn = new JButton("Quit");
        exitBtn.setFont(new Font("Arial", Font.ITALIC, 14));
        exitBtn.setForeground(Color.red);
        exitBtn.addActionListener((e) -> {
            System.exit(0);
        });
    }

    private void createPanel() {
        JPanel panel = new JPanel();
        panel.add(label);
        panel.add(labelImg);
        panel.add(jta);
        JScrollPane scrollPane = new JScrollPane(jta);
        panel.add(scrollPane);
        panel.add(fortuneBtn);
        panel.add(exitBtn);
        add(panel);
    }
}
