package ttt;

import javax.swing.JFrame;

/**
 * This program runs a TicTacToe game. It prompts the user to set positions on
 * the board and prints out the result.
 */
public class TicTacToeRunner {

    public static void main(String[] args) {
        
        JFrame frame = new TicTacToeFrame();
    }
}
